 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/timer/delay.h"
#include "OLED128x64.h"

#define     ADDR_MCP9800A5  0x4d           // 1001101 = 4d

char                    ASCII_Buffer[20];
volatile unsigned char  I2C_Wbuffer[16];   
volatile unsigned char  I2C_Rbuffer[16] ;
int                     VR_ReadValue ;
volatile bool           bTimeoutFlag = 0 ;

union
{
    char   ByteVal[2];
    int    WordValue ;
}MCP9800_Data;

void    User_Timer_ISR(void)
{
    LED1_Toggle();
    bTimeoutFlag = 1 ;
}

/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 
    
    Timer1.TimeoutCallbackRegister(User_Timer_ISR);
    Timer1.Start();
    
    ADC_Enable();

        OLED_Init();      
        OLED_CLS(); 
        OLED_Put8x16Str(0,0,"I'm PIC16F15245");    
        OLED_Put8x16Str(0,2,"On APP-MASTERS25");    
        OLED_Put8x16Str(0,4,"MCP9800A5:");  
        OLED_Put8x16Str(0,6,"VR:");  

    while(1)
    {
        if (bTimeoutFlag)
        {
            PWM1_Toggle();
            printf("I am PIC16F1 \n\r") ; 

            VR_ReadValue = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANB6);

                    // Read =Temperature data from MCP9800A5
                    // -------------------------------------
                    I2C_Wbuffer[0] = 0;
                    I2C1_Host.WriteRead(ADDR_MCP9800A5,I2C_Wbuffer,1,I2C_Rbuffer,2);
                    while ( I2C1_Host.IsBusy()) ;

                    MCP9800_Data.ByteVal[0]= I2C_Rbuffer[1];
                    MCP9800_Data.ByteVal[1]= I2C_Rbuffer[0];

                     sprintf (ASCII_Buffer,"%2d.%1d C",I2C_Rbuffer[0], (I2C_Rbuffer[1] *10)/256) ;
                     OLED_Put8x16Str(80,4,(uint8_t*)ASCII_Buffer) ; 

                     sprintf (ASCII_Buffer,"%4d",VR_ReadValue ) ;
                     OLED_Put8x16Str(80,6,(uint8_t*)ASCII_Buffer) ;    
                     
                     bTimeoutFlag = 0 ;
        }
    }    
}