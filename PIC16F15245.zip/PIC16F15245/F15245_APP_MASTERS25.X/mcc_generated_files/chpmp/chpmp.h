/**
 * CHPMP Generated Driver API Header File
 * 
 * @file chpmp.h
 * 
 * @defgroup  chpmp
 * 
 * @brief This file contains the API prototypes for the Charge Pump (CHPMP) driver.
 *
 * @version CHPMP Source Code Driver Version 1.0.0
*/
/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef CHPMP_H
#define CHPMP_H

/**
  Section: Included Files
*/

#include <stdbool.h>
#include <stdint.h>

/**
 * @ingroup chpmp
 * @brief Initializes the CHPMP module.
 * @param None.
 * @return None.
 */
void CHPMP_Initialize(void);

/**
 * @ingroup chpmp
 * @brief Returns the status of the CHPMP threshold 
 * @param  None.
 * @retval True - VDD is above the threshold voltage(VAUTO)
 * @retval False - VDD is below the threshold voltage(VAUTO)
 */
bool CHPMP_IsVDDAboveVAuto(void);

/**
 * @ingroup chpmp
 * @brief Returns the status of Steady state. 
 * @param  None.
 * @retval True - Steady state is reached
 * @retval False - Steady state is not reached
 */
bool CHPMP_IsReady(void);

#endif // CHPMP_H
/**
 End of File
*/
