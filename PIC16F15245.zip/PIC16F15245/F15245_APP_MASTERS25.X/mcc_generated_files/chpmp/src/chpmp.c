/**
 * CHPMP Generated Driver File
 * 
 * @file chpmp.c
 * 
 * @ingroup chpmp
 * 
 * @brief This file contains the API implementations for the Charge Pump (CHPMP) driver.
 *
 * @version CHPMP Source Code Driver Version 1.0.0
 * @version CHPMP Melody Peripheral Library (PLIB) version 1.0.0
*/
/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

/**
  Section: Included Files
*/

#include <xc.h>
#include "../chpmp.h"

void CHPMP_Initialize(void)
{
	CPCON = (1 << _CPCON_CPON_POSN);  // CPON enabled when Vdd < Vauto(4.6V) and any analog peripheral is ON(1)
}

bool CHPMP_IsVDDAboveVAuto(void)
{
	return (CPCONbits.CPT);
}

bool CHPMP_IsReady(void)
{
	return (CPCONbits.CPRDY);
}

/**
 End of File
*/